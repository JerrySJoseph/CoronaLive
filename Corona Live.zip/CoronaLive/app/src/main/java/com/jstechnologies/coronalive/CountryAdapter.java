package com.jstechnologies.coronalive;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class CountryAdapter extends RecyclerView.Adapter<CountryViewHolder> {

    ArrayList<DataModel>models;

    public CountryAdapter(ArrayList<DataModel> models) {
        this.models = models;
    }

    @NonNull
    @Override
    public CountryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_countries, parent, false);

        return new CountryViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull CountryViewHolder holder, int position) {

        holder.id.setText((position+1)+".");
        holder.name.setText(models.get(position).getCountry_name());
        holder.cases.setText(models.get(position).getCases());

    }

    @Override
    public int getItemCount() {
        return models.size();
    }
}
