package com.jstechnologies.coronalive;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class CountryViewHolder extends RecyclerView.ViewHolder {

    TextView id,name,cases;
    ImageView flag;

    public CountryViewHolder(@NonNull View itemView) {
        super(itemView);
        id=itemView.findViewById(R.id.number);
        name=itemView.findViewById(R.id.name);
        cases=itemView.findViewById(R.id.cases);
        flag=itemView.findViewById(R.id.flag);
    }
}
